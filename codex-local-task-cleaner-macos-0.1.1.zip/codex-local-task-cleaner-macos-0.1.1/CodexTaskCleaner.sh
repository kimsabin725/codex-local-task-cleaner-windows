#!/bin/zsh

emulate -LR zsh
setopt NO_UNSET PIPE_FAIL NO_NOMATCH EXTENDED_GLOB
umask 077

readonly VERSION='0.1.1'
readonly SCRIPT_DIR="${0:A:h}"
readonly JSON_HELPER="$SCRIPT_DIR/CodexTaskCleanerJson.js"
readonly SQLITE3='/usr/bin/sqlite3'
readonly OSASCRIPT='/usr/bin/osascript'
readonly DITTO='/usr/bin/ditto'
readonly LSOF='/usr/sbin/lsof'

typeset -gra METADATA_DATABASE_NAMES=(
    logs_2.sqlite goals_1.sqlite memories_1.sqlite queue_1.sqlite state_5.sqlite
)
typeset -grA MAX_SUPPORTED_MIGRATION=(
    state_5.sqlite 48
    logs_2.sqlite 2
    goals_1.sqlite 2
    memories_1.sqlite 1
    queue_1.sqlite 1
)

typeset -g CODEX_HOME="$HOME/.codex"
typeset -g BACKUP_ROOT="$HOME/Library/Application Support/CodexTaskCleaner/Backups"
typeset -g SHOW_ALL=0
typeset -g LIST_ONLY=0
typeset -g EXECUTE=0
typeset -g ASSUME_YES=0
typeset -g REMOVE_WORKSPACES=0
typeset -g SKIP_PROCESS_CHECK=0
typeset -g TEMP_DIR=''
typeset -g BACKUP_PATH=''
typeset -g MUTATION_STARTED=0
typeset -g CLEANUP_VERIFIED=0
typeset -g RESTORE_ATTEMPTED=0
typeset -g DB_RESULT=''
typeset -g ERROR_DETAIL=''
typeset -g MOVE_FAILURES=0

typeset -ga REQUESTED_IDS=()
typeset -ga SELECTED_IDS=()
typeset -ga DESCENDANT_IDS=()
typeset -ga THREAD_IDS=()
typeset -ga THREAD_LABELS=()
typeset -ga THREAD_CWDS=()
typeset -ga THREAD_ROLLOUTS=()
typeset -ga THREAD_SOURCES=()
typeset -ga THREAD_THREAD_SOURCES=()
typeset -ga THREAD_UPDATED=()
typeset -ga THREAD_UPDATED_IS_MS=()
typeset -ga SELECTED_INDICES=()
typeset -ga REMAINING_INDICES=()
typeset -ga TARGET_ITEMS=()
typeset -ga BACKUP_CORE_NAMES=()
typeset -ga BACKUP_PAYLOAD_RELATIVE=()
typeset -ga DISCOVERED_TABLES=()
typeset -gA SELECTED_SET
typeset -gA TARGET_SET

print_heading() {
    print
    print -P "%F{cyan}=== $1 ===%f"
}

warn() {
    print -P "%F{yellow}WARNING: $*%f" >&2
}

cleanup_temp() {
    if [[ -n "$TEMP_DIR" && -d "$TEMP_DIR" ]]; then
        local temp_parent="${TMPDIR:-/tmp}"
        local temp_abs="${TEMP_DIR:A}"
        local parent_abs="${temp_parent:A}"
        if [[ "$temp_abs" == "$parent_abs"/codex-task-cleaner.* ]]; then
            /bin/rm -rf -- "$temp_abs"
        fi
    fi
}
trap cleanup_temp EXIT

usage() {
    cat <<'EOF'
Codex Local Task Cleaner for macOS

Usage:
  ./CodexTaskCleaner.sh                     Interactive mode
  ./CodexTaskCleaner.sh --list              List user tasks
  ./CodexTaskCleaner.sh --list --show-all   Include automations and subagents
  ./CodexTaskCleaner.sh --id UUID           Preview one task
  ./CodexTaskCleaner.sh --id UUID --execute

Options:
  --id UUID                 Select a task. May be repeated.
  --list                    List tasks without changing anything.
  --show-all                Include internal automations and subagents.
  --execute                 Perform deletion after confirmation.
  --yes                     Skip DELETE prompt in non-interactive mode.
  --remove-workspaces       Move dedicated task folders to Trash.
  --codex-home PATH         Override ~/.codex.
  --backup-root PATH        Override the backup folder.
  --skip-process-check      Advanced/testing only.
  --help                    Show this help.
EOF
}

restore_backup() {
    (( RESTORE_ATTEMPTED )) && return 1
    RESTORE_ATTEMPTED=1
    [[ -n "$BACKUP_PATH" && -d "$BACKUP_PATH" ]] || return 1

    print -P "%F{yellow}Restoring recovery backup...%f" >&2
    local name current source destination relative
    for name in $METADATA_DATABASE_NAMES; do
        for suffix in '' '-wal' '-shm'; do
            current="$CODEX_HOME/$name$suffix"
            if [[ -e "$current" || -L "$current" ]]; then
                [[ ! -L "$current" && "${current:a}" == "$CODEX_HOME"/* ]] || return 1
                /bin/rm -f -- "$current" || return 1
            fi
        done
    done

    for name in $BACKUP_CORE_NAMES; do
        source="$BACKUP_PATH/core/$name"
        destination="$CODEX_HOME/$name"
        [[ -e "$source" && "${destination:a}" == "$CODEX_HOME"/* ]] || return 1
        if [[ -e "$destination" || -L "$destination" ]]; then
            [[ ! -L "$destination" ]] || return 1
            /bin/rm -f -- "$destination" || return 1
        fi
        "$DITTO" --rsrc --extattr "$source" "$destination" || return 1
    done

    for relative in $BACKUP_PAYLOAD_RELATIVE; do
        source="$BACKUP_PATH/payload/$relative"
        destination="$CODEX_HOME/$relative"
        [[ -e "$source" || -L "$source" ]] || return 1
        [[ "${destination:a}" == "$CODEX_HOME"/* ]] || return 1
        if [[ -e "$destination" || -L "$destination" ]]; then
            [[ ! -L "$destination" ]] || return 1
            if [[ -d "$destination" ]]; then
                /bin/rm -rf -- "$destination" || return 1
            else
                /bin/rm -f -- "$destination" || return 1
            fi
        fi
        /bin/mkdir -p -- "${destination:h}" || return 1
        "$DITTO" --rsrc --extattr "$source" "$destination" || return 1
    done
    verify_restored_state
}

die() {
    local message="$*"
    print >&2
    if (( MUTATION_STARTED && ! CLEANUP_VERIFIED )); then
        if restore_backup; then
            print -P "%F{green}Recovery backup restored successfully.%f" >&2
        else
            print -P "%F{red}Automatic restore did not complete. Keep this backup: $BACKUP_PATH%f" >&2
        fi
    fi
    print -P "%F{red}ERROR: $message%f" >&2
    exit 1
}

require_command() {
    [[ -x "$1" ]] || die "Required macOS tool was not found: $1"
}

normalize_path() {
    local value="$1"
    [[ -n "$value" ]] || return 1
    REPLY="${value:A}"
}

path_identity() {
    local value="$1"
    normalize_path "$value" || return 1
    local normalized="$REPLY"
    [[ -e "$normalized" && ! -L "$normalized" ]] || return 1
    REPLY=$(/usr/bin/stat -f '%d:%i' "$normalized" 2>/dev/null) || return 1
    [[ -n "$REPLY" ]]
}

same_existing_path() {
    local left="$1"
    local right="$2"
    path_identity "$left" || return 1
    local left_identity="$REPLY"
    path_identity "$right" || return 1
    [[ "$REPLY" == "$left_identity" ]]
}

is_within() {
    local child="$1"
    local parent="$2"
    normalize_path "$child" || return 1
    local child_full="${REPLY%/}"
    normalize_path "$parent" || return 1
    local parent_full="${REPLY%/}"
    if [[ -e "$child_full" && ! -L "$child_full" && -e "$parent_full" && ! -L "$parent_full" ]]; then
        path_identity "$parent_full" || return 1
        local parent_identity="$REPLY"
        local current="$child_full" next
        while true; do
            path_identity "$current" || return 1
            [[ "$REPLY" == "$parent_identity" ]] && return 0
            next="${current:h}"
            [[ "$next" != "$current" ]] || return 1
            current="$next"
        done
    fi
    [[ "$child_full" == "$parent_full" || "$child_full" == "$parent_full"/* ]]
}

sql_quote() {
    local value="$1"
    REPLY="'${value//\'/\'\'}'"
}

sql_identifier() {
    local value="$1"
    REPLY="\"${value//\"/\"\"}\""
}

db_query() {
    local database="$1"
    local sql="$2"
    local output
    output=$("$SQLITE3" -batch -bail -cmd '.timeout 5000' "$database" "$sql" 2>&1)
    local exit_code=$?
    if (( exit_code != 0 )); then
        ERROR_DETAIL="$output"
        DB_RESULT=''
        return $exit_code
    fi
    DB_RESULT="$output"
    return 0
}

db_execute() {
    db_query "$1" "$2"
}

db_has_column() {
    local database="$1"
    local table="$2"
    local column="$3"
    sql_quote "$table"
    local table_sql="$REPLY"
    sql_quote "$column"
    local column_sql="$REPLY"
    db_query "$database" "SELECT 1 FROM pragma_table_info($table_sql) WHERE name=$column_sql LIMIT 1;" || return 1
    [[ "$DB_RESULT" == '1' ]]
}

table_exists() {
    local database="$1"
    local table="$2"
    sql_quote "$table"
    db_query "$database" "SELECT 1 FROM sqlite_master WHERE type='table' AND name=$REPLY LIMIT 1;" || return 1
    [[ "$DB_RESULT" == '1' ]]
}

database_integrity_ok() {
    local database="$1"
    db_query "$database" 'PRAGMA integrity_check;' || return 1
    if [[ "$DB_RESULT" != 'ok' ]]; then
        ERROR_DETAIL="SQLite integrity check failed for $database: $DB_RESULT"
        return 1
    fi
    return 0
}

decode_hex() {
    local value="$1" byte decoded=''
    (( ${#value} % 2 == 0 )) || return 1
    [[ -z "$value" || "$value" == [0-9a-fA-F]## ]] || return 1
    while [[ -n "$value" ]]; do
        byte="${value[1,2]}"
        local piece=''
        printf -v piece '%b' "\\x$byte" || return 1
        decoded+="$piece"
        value="${value[3,-1]}"
    done
    REPLY="$decoded"
}

base64_text() {
    REPLY=$(print -rn -- "$1" | /usr/bin/base64 | /usr/bin/tr -d '\r\n') || return 1
}

assert_core_files_safe() {
    local name suffix file
    for name in $METADATA_DATABASE_NAMES; do
        for suffix in '' '-wal' '-shm'; do
            file="$CODEX_HOME/$name$suffix"
            [[ ! -L "$file" ]] || die "Refusing symbolic-link metadata file: $file"
            [[ ! -e "$file" || -f "$file" ]] || die "Metadata path is not a regular file: $file"
        done
    done
    for name in session_index.jsonl version.json .codex-global-state.json .codex-global-state.json.bak; do
        file="$CODEX_HOME/$name"
        [[ ! -L "$file" ]] || die "Refusing symbolic-link metadata file: $file"
        [[ ! -e "$file" || -f "$file" ]] || die "Metadata path is not a regular file: $file"
    done
    local -a temporary_state_files=("$CODEX_HOME"/..codex-global-state.json.tmp-*(N))
    for file in $temporary_state_files; do
        [[ ! -L "$file" ]] || die "Refusing symbolic-link metadata file: $file"
        [[ -f "$file" ]] || die "Metadata path is not a regular file: $file"
    done
}

assert_supported_schema() {
    assert_core_files_safe

    local -A allowed_databases
    local name file migration maximum
    for name in $METADATA_DATABASE_NAMES; do allowed_databases[$name]=1; done
    local -a sqlite_files=("$CODEX_HOME"/*.sqlite(N))
    for file in $sqlite_files; do
        name="${file:t}"
        [[ ! -L "$file" && -f "$file" ]] || die "Unsafe SQLite metadata file: $file"
        [[ -n "${allowed_databases[$name]-}" ]] || die "Unsupported Codex SQLite file was found: $name. Update the cleaner before deleting anything."
    done

    local state_db="$CODEX_HOME/state_5.sqlite"
    [[ -f "$state_db" && ! -L "$state_db" ]] || die "Missing or unsafe state database: $state_db"
    for name in $METADATA_DATABASE_NAMES; do
        file="$CODEX_HOME/$name"
        [[ -f "$file" ]] || continue
        database_integrity_ok "$file" || die "$ERROR_DETAIL"
        table_exists "$file" '_sqlx_migrations' || die "Unsupported Codex schema: $name has no migration history."
        db_query "$file" 'SELECT COUNT(*) FROM _sqlx_migrations WHERE success <> 1;' || die "Could not inspect $name migrations: $ERROR_DETAIL"
        [[ "$DB_RESULT" == '0' ]] || die "Unsupported Codex schema: $name contains a failed migration."
        db_query "$file" 'SELECT COALESCE(MAX(version),0) FROM _sqlx_migrations WHERE success = 1;' || die "Could not inspect $name migrations: $ERROR_DETAIL"
        migration="$DB_RESULT"
        maximum="${MAX_SUPPORTED_MIGRATION[$name]}"
        [[ "$migration" == <-> ]] || die "Unsupported Codex migration value in $name."
        (( migration <= maximum )) || die "Codex storage is newer than this cleaner supports: $name migration $migration (maximum $maximum)."
    done

    table_exists "$state_db" 'threads' || die 'Unsupported Codex schema: threads table is missing.'
    local required
    for required in id rollout_path cwd; do
        db_has_column "$state_db" 'threads' "$required" || die "Unsupported Codex schema: threads.$required is missing."
    done
}

load_threads() {
    local database="$CODEX_HOME/state_5.sqlite"
    local -a label_parts=()
    local column
    for column in name title preview first_user_message; do
        if db_has_column "$database" 'threads' "$column"; then
            sql_identifier "$column"
            label_parts+=("NULLIF($REPLY,'')")
        fi
    done
    local label_expression="'(untitled)'"
    if (( ${#label_parts} )); then
        label_expression="COALESCE(${(j:,:)label_parts},'(untitled)')"
    fi

    local source_expression="''"
    if db_has_column "$database" 'threads' 'source'; then source_expression="COALESCE(\"source\",'')"; fi
    local thread_source_expression="''"
    if db_has_column "$database" 'threads' 'thread_source'; then thread_source_expression="COALESCE(\"thread_source\",'')"; fi
    local updated_expression="''"
    local updated_is_ms='0'
    if db_has_column "$database" 'threads' 'updated_at_ms'; then
        updated_expression="COALESCE(CAST(\"updated_at_ms\" AS TEXT),'')"
        updated_is_ms='1'
    elif db_has_column "$database" 'threads' 'updated_at'; then
        updated_expression="COALESCE(CAST(\"updated_at\" AS TEXT),'')"
    fi

    local sql
    sql="SELECT COALESCE(hex(CAST(\"id\" AS BLOB)),'')||'|'||"
    sql+="COALESCE(hex(CAST(\"rollout_path\" AS BLOB)),'')||'|'||"
    sql+="COALESCE(hex(CAST(\"cwd\" AS BLOB)),'')||'|'||"
    sql+="COALESCE(hex(CAST($label_expression AS BLOB)),'')||'|'||"
    sql+="COALESCE(hex(CAST($source_expression AS BLOB)),'')||'|'||"
    sql+="COALESCE(hex(CAST($thread_source_expression AS BLOB)),'')||'|'||"
    sql+="$updated_expression FROM threads"
    if [[ "$updated_expression" != "''" ]]; then
        if (( updated_is_ms )); then sql+=' ORDER BY "updated_at_ms" DESC'; else sql+=' ORDER BY "updated_at" DESC'; fi
    else
        sql+=' ORDER BY "id" DESC'
    fi
    sql+=';'

    db_query "$database" "$sql" || die "Could not read Codex tasks: $ERROR_DETAIL"

    THREAD_IDS=()
    THREAD_ROLLOUTS=()
    THREAD_CWDS=()
    THREAD_LABELS=()
    THREAD_SOURCES=()
    THREAD_THREAD_SOURCES=()
    THREAD_UPDATED=()
    THREAD_UPDATED_IS_MS=()

    local id_hex rollout_hex cwd_hex label_hex source_hex thread_source_hex updated
    local id rollout cwd label source thread_source
    while IFS='|' read -r id_hex rollout_hex cwd_hex label_hex source_hex thread_source_hex updated; do
        [[ -n "$id_hex" ]] || continue
        decode_hex "$id_hex" || die 'Could not decode a task ID.'; id="$REPLY"
        decode_hex "$rollout_hex" || die 'Could not decode a rollout path.'; rollout="$REPLY"
        decode_hex "$cwd_hex" || die 'Could not decode a workspace path.'; cwd="$REPLY"
        decode_hex "$label_hex" || die 'Could not decode a task title.'; label="$REPLY"
        decode_hex "$source_hex" || die 'Could not decode a task source.'; source="$REPLY"
        decode_hex "$thread_source_hex" || die 'Could not decode a thread source.'; thread_source="$REPLY"
        if [[ "$cwd" == *$'\n'* || "$rollout" == *$'\n'* ]]; then
            die "A task contains an unsupported newline in its path: $id"
        fi
        THREAD_IDS+=("$id")
        THREAD_ROLLOUTS+=("$rollout")
        THREAD_CWDS+=("$cwd")
        THREAD_LABELS+=("$label")
        THREAD_SOURCES+=("$source")
        THREAD_THREAD_SOURCES+=("$thread_source")
        THREAD_UPDATED+=("$updated")
        THREAD_UPDATED_IS_MS+=("$updated_is_ms")
    done <<< "$DB_RESULT"
}

thread_kind() {
    local index="$1"
    local source="${THREAD_SOURCES[$index]}"
    local thread_source="${THREAD_THREAD_SOURCES[$index]}"
    local label="${THREAD_LABELS[$index]}"
    if [[ "$thread_source" == 'subagent' || "$source" == *subagent* ]]; then
        REPLY='하위작업'
    elif [[ "$source" == 'exec' || "$label" == "You are executing an authenticated owner's request"* ]]; then
        REPLY='자동화'
    else
        REPLY='일반대화'
    fi
}

truncate_text() {
    local value="${1//$'\n'/ }"
    value="${value//$'\r'/ }"
    local limit="$2"
    if (( ${#value} > limit )); then value="${value[1,limit]}"; fi
    REPLY="$value"
}

updated_text() {
    local value="$1"
    local is_ms="$2"
    if [[ "$value" != <-> ]]; then REPLY='-'; return; fi
    local seconds="$value"
    if (( is_ms || seconds > 100000000000 )); then seconds=$(( seconds / 1000 )); fi
    REPLY=$(/bin/date -r "$seconds" '+%m-%d %H:%M' 2>/dev/null) || REPLY='-'
}

show_threads() {
    local -a indices=("$@")
    printf '%-4s %-10s %-40s %-12s %-24s %-8s\n' 'No' '종류' '제목' '수정' '폴더' 'ID끝'
    printf '%-4s %-10s %-40s %-12s %-24s %-8s\n' '--' '----------' '----------------------------------------' '------------' '------------------------' '--------'
    local display_no=0 index kind title folder updated short_id cwd
    for index in $indices; do
        (( display_no++ ))
        thread_kind "$index"; kind="$REPLY"
        truncate_text "${THREAD_LABELS[$index]}" 38; title="$REPLY"
        cwd="${THREAD_CWDS[$index]}"
        folder="${cwd:t}"
        truncate_text "$folder" 22; folder="$REPLY"
        updated_text "${THREAD_UPDATED[$index]}" "${THREAD_UPDATED_IS_MS[$index]}"; updated="$REPLY"
        short_id="${THREAD_IDS[$index][-8,-1]}"
        printf '%-4s %-10s %-40s %-12s %-24s %-8s\n' "$display_no" "$kind" "$title" "$updated" "$folder" "$short_id"
    done
}

show_selected() {
    local index no=0
    for index in $SELECTED_INDICES; do
        (( no++ ))
        thread_kind "$index"
        print "[$no] ${THREAD_LABELS[$index]}"
        print "    종류: $REPLY"
        print "    ID:   ${THREAD_IDS[$index]}"
        print "    폴더: ${THREAD_CWDS[$index]}"
    done
}

assert_app_closed() {
    (( SKIP_PROCESS_CHECK )) && return
    if /usr/bin/pgrep -x 'ChatGPT' >/dev/null 2>&1 || /usr/bin/pgrep -x 'Codex' >/dev/null 2>&1; then
        die 'ChatGPT is still running. Quit it completely, including its menu-bar item, and run this utility again.'
    fi
    local -a database_files=(
        "$CODEX_HOME"/*.sqlite(N)
        "$CODEX_HOME"/*.sqlite-wal(N)
        "$CODEX_HOME"/*.sqlite-shm(N)
    )
    local file
    for file in $database_files; do
        [[ -f "$file" && ! -L "$file" ]] || continue
        if "$LSOF" -t "$file" >/dev/null 2>&1; then
            die "A background process is still using Codex metadata: $file. Quit ChatGPT/Codex completely and try again."
        fi
    done
}

collect_descendants() {
    local database="$CODEX_HOME/state_5.sqlite"
    DESCENDANT_IDS=()
    table_exists "$database" 'thread_spawn_edges' || return 0
    db_has_column "$database" 'thread_spawn_edges' 'parent_thread_id' || return 0
    db_has_column "$database" 'thread_spawn_edges' 'child_thread_id' || return 0
    db_query "$database" "SELECT COALESCE(hex(CAST(parent_thread_id AS BLOB)),'' )||'|'||COALESCE(hex(CAST(child_thread_id AS BLOB)),'') FROM thread_spawn_edges;" || die "Could not inspect descendant tasks: $ERROR_DETAIL"
    local -a parents=() children=()
    local parent_hex child_hex parent child
    while IFS='|' read -r parent_hex child_hex; do
        [[ -n "$parent_hex" && -n "$child_hex" ]] || continue
        decode_hex "$parent_hex" || die 'Could not decode a parent task ID.'; parent="$REPLY"
        decode_hex "$child_hex" || die 'Could not decode a child task ID.'; child="$REPLY"
        parents+=("$parent")
        children+=("$child")
    done <<< "$DB_RESULT"

    local changed=1 i child_id
    while (( changed )); do
        changed=0
        for (( i=1; i<=${#parents}; i++ )); do
            if [[ -n "${SELECTED_SET[${parents[$i]}]-}" && -z "${SELECTED_SET[${children[$i]}]-}" ]]; then
                child_id="${children[$i]}"
                SELECTED_SET[$child_id]=1
                DESCENDANT_IDS+=("$child_id")
                changed=1
            fi
        done
    done
}

find_automation_reference() {
    local folder="$CODEX_HOME/automations"
    [[ -d "$folder" && ! -L "$folder" ]] || return 1
    local -a files=("$folder"/**/*(.N))
    local file id
    for file in $files; do
        for id in $SELECTED_IDS; do
            if /usr/bin/grep -Fq -- "$id" "$file" 2>/dev/null; then
                REPLY="$file"
                return 0
            fi
        done
    done
    return 1
}

add_target_item() {
    local value="$1"
    [[ -n "$value" && ( -e "$value" || -L "$value" ) ]] || return
    local absolute="${value:a}"
    if [[ -z "${TARGET_SET[$absolute]-}" ]]; then
        TARGET_SET[$absolute]=1
        TARGET_ITEMS+=("$absolute")
    fi
}

collect_target_items() {
    TARGET_ITEMS=()
    TARGET_SET=()
    local index rollout folder item id visualization
    for index in $SELECTED_INDICES; do
        rollout="${THREAD_ROLLOUTS[$index]}"
        add_target_item "$rollout"
    done

    for folder in "$CODEX_HOME/sessions" "$CODEX_HOME/archived_sessions" "$CODEX_HOME/thread-writer-locks"; do
        [[ -d "$folder" && ! -L "$folder" ]] || continue
        local -a files=("$folder"/**/*(.N))
        for item in $files; do
            for id in $SELECTED_IDS; do
                if [[ "${item:t}" == *"$id"* ]]; then add_target_item "$item"; break; fi
            done
        done
    done

    visualization="$CODEX_HOME/visualizations"
    if [[ -d "$visualization" && ! -L "$visualization" ]]; then
        local -a directories=("$visualization"/**/*(/N))
        for item in $directories; do
            if [[ -n "${SELECTED_SET[${item:t}]-}" ]]; then add_target_item "$item"; fi
        done
    fi
}

core_files() {
    local -a names=($METADATA_DATABASE_NAMES session_index.jsonl version.json)
    local name file
    BACKUP_CORE_NAMES=()
    for name in $names; do
        file="$CODEX_HOME/$name"
        [[ -f "$file" && ! -L "$file" ]] && BACKUP_CORE_NAMES+=("$name")
    done
    local -a state_files=(
        "$CODEX_HOME/.codex-global-state.json"(N)
        "$CODEX_HOME/.codex-global-state.json.bak"(N)
        "$CODEX_HOME"/..codex-global-state.json.tmp-*(N)
    )
    for file in $state_files; do
        [[ -f "$file" && ! -L "$file" ]] || continue
        BACKUP_CORE_NAMES+=("${file:t}")
    done
    BACKUP_CORE_NAMES=("${(@u)BACKUP_CORE_NAMES}")
}

backup_database() {
    local source="$1"
    local destination="$2"
    database_integrity_ok "$source" || return 1
    [[ ! -e "$destination" && ! -L "$destination" ]] || { ERROR_DETAIL="Backup destination already exists: $destination"; return 1; }
    sql_quote "$destination"
    local destination_sql="$REPLY"
    db_execute "$source" "VACUUM INTO $destination_sql;" || return 1
    database_integrity_ok "$destination"
}

write_manifest() {
    local manifest="$BACKUP_PATH/manifest.json"
    local i index comma relative
    {
        print '{'
        print "  \"formatVersion\": 1,"
        print "  \"cleanerVersion\": \"$VERSION\","
        print "  \"createdAt\": \"$(/bin/date -u '+%Y-%m-%dT%H:%M:%SZ')\","
        base64_text "$CODEX_HOME" || return 1
        print "  \"codexHomeBase64\": \"$REPLY\","
        print '  "ids": ['
        for (( i=1; i<=${#SELECTED_IDS}; i++ )); do
            comma=','; (( i == ${#SELECTED_IDS} )) && comma=''
            print "    \"${SELECTED_IDS[$i]}\"$comma"
        done
        print '  ],'
        print '  "tasks": ['
        for (( i=1; i<=${#SELECTED_INDICES}; i++ )); do
            index="${SELECTED_INDICES[$i]}"
            comma=','; (( i == ${#SELECTED_INDICES} )) && comma=''
            base64_text "${THREAD_LABELS[$index]}" || return 1; local title_b64="$REPLY"
            base64_text "${THREAD_CWDS[$index]}" || return 1; local cwd_b64="$REPLY"
            base64_text "${THREAD_ROLLOUTS[$index]}" || return 1; local rollout_b64="$REPLY"
            print '    {'
            print "      \"id\": \"${THREAD_IDS[$index]}\","
            print "      \"titleBase64\": \"$title_b64\","
            print "      \"cwdBase64\": \"$cwd_b64\","
            print "      \"rolloutPathBase64\": \"$rollout_b64\""
            print "    }$comma"
        done
        print '  ],'
        print '  "coreFiles": ['
        for (( i=1; i<=${#BACKUP_CORE_NAMES}; i++ )); do
            comma=','; (( i == ${#BACKUP_CORE_NAMES} )) && comma=''
            base64_text "${BACKUP_CORE_NAMES[$i]}" || return 1
            print "    \"$REPLY\"$comma"
        done
        print '  ],'
        print '  "payloadItemsBase64": ['
        for (( i=1; i<=${#BACKUP_PAYLOAD_RELATIVE}; i++ )); do
            comma=','; (( i == ${#BACKUP_PAYLOAD_RELATIVE} )) && comma=''
            relative="${BACKUP_PAYLOAD_RELATIVE[$i]}"
            base64_text "$relative" || return 1
            print "    \"$REPLY\"$comma"
        done
        print '  ]'
        print '}'
    } >| "$manifest" || return 1
}

create_backup() {
    /bin/mkdir -p -- "$BACKUP_ROOT" || die "Could not create backup root: $BACKUP_ROOT"
    BACKUP_ROOT="${BACKUP_ROOT:A}"
    local stamp=$(/bin/date '+%Y%m%d-%H%M%S')
    BACKUP_PATH="$BACKUP_ROOT/backup-$stamp-$$-$RANDOM"
    [[ "$BACKUP_PATH" == "$BACKUP_ROOT"/backup-* ]] || die 'Refusing unsafe backup path.'
    /bin/mkdir -p -- "$BACKUP_PATH/core" "$BACKUP_PATH/payload" || die 'Could not create the recovery backup.'

    core_files
    local name source destination item relative
    for name in $BACKUP_CORE_NAMES; do
        source="$CODEX_HOME/$name"
        destination="$BACKUP_PATH/core/$name"
        if [[ "$name" == *.sqlite ]]; then
            backup_database "$source" "$destination" || die "Could not create a consistent database backup for $source: $ERROR_DETAIL"
        else
            "$DITTO" --rsrc --extattr "$source" "$destination" || die "Could not back up: $source"
        fi
    done

    BACKUP_PAYLOAD_RELATIVE=()
    for item in $TARGET_ITEMS; do
        [[ ! -L "$item" ]] || die "Refusing to back up a symbolic link target: $item"
        is_within "$item" "$CODEX_HOME" || die "Refusing to back up a path outside Codex home: $item"
        [[ "$item" != "$CODEX_HOME" ]] || die 'Refusing to back up the entire Codex home.'
        relative="${item#$CODEX_HOME/}"
        [[ -n "$relative" && "$relative" != "$item" ]] || die "Could not derive a safe backup path: $item"
        destination="$BACKUP_PATH/payload/$relative"
        /bin/mkdir -p -- "${destination:h}" || die 'Could not prepare the backup payload.'
        "$DITTO" --rsrc --extattr "$item" "$destination" || die "Could not back up: $item"
        BACKUP_PAYLOAD_RELATIVE+=("$relative")
    done
    write_manifest || die 'Could not write backup manifest.'
}

discover_thread_tables() {
    local database="$1"
    DISCOVERED_TABLES=()
    db_query "$database" "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;" || return 1
    local -a tables=("${(@f)DB_RESULT}")
    local table
    for table in $tables; do
        [[ -n "$table" && "$table" != sqlite_* && "$table" != '_sqlx_migrations' ]] || continue
        if [[ "$table" == 'threads' ]] || db_has_column "$database" "$table" 'thread_id' || db_has_column "$database" "$table" 'parent_thread_id' || db_has_column "$database" "$table" 'child_thread_id'; then
            DISCOVERED_TABLES+=("$table")
        fi
    done
    return 0
}

selected_id_list_sql() {
    local -a quoted=()
    local id
    for id in $SELECTED_IDS; do
        sql_quote "$id"
        quoted+=("$REPLY")
    done
    REPLY="${(j:,:)quoted}"
}

verify_restored_state() {
    local name database source destination relative
    for name in $METADATA_DATABASE_NAMES; do
        database="$CODEX_HOME/$name"
        [[ -f "$database" && ! -L "$database" ]] || continue
        database_integrity_ok "$database" || return 1
    done

    selected_id_list_sql
    local id_list="$REPLY"
    db_query "$CODEX_HOME/state_5.sqlite" "SELECT COUNT(*) FROM threads WHERE id IN ($id_list);" || return 1
    [[ "$DB_RESULT" == "${#SELECTED_IDS}" ]] || { ERROR_DETAIL="Restored state database does not contain every selected task."; return 1; }

    for name in $BACKUP_CORE_NAMES; do
        [[ "$name" == *.sqlite ]] && continue
        source="$BACKUP_PATH/core/$name"
        destination="$CODEX_HOME/$name"
        [[ -f "$source" && -f "$destination" && ! -L "$destination" ]] || return 1
        /usr/bin/cmp -s "$source" "$destination" || { ERROR_DETAIL="Restored metadata differs from its backup: $name"; return 1; }
    done
    for relative in $BACKUP_PAYLOAD_RELATIVE; do
        destination="$CODEX_HOME/$relative"
        [[ -e "$destination" && ! -L "$destination" ]] || { ERROR_DETAIL="Restored payload is missing: $relative"; return 1; }
    done
    return 0
}

delete_database_rows() {
    local database="$1"
    [[ ! -L "$database" ]] || { ERROR_DETAIL="Refusing symbolic-link database: $database"; return 1; }
    [[ -f "$database" ]] || return 0
    discover_thread_tables "$database" || return 1
    local -a tables=("${DISCOVERED_TABLES[@]}")
    selected_id_list_sql
    local id_list="$REPLY"
    local statements='BEGIN IMMEDIATE;'
    local table column table_identifier column_identifier
    local -a conditions=()

    for table in $tables; do
        [[ "$table" != 'threads' ]] || continue
        conditions=()
        sql_identifier "$table"; table_identifier="$REPLY"
        for column in thread_id parent_thread_id child_thread_id; do
            if db_has_column "$database" "$table" "$column"; then
                sql_identifier "$column"; column_identifier="$REPLY"
                conditions+=("$column_identifier IN ($id_list)")
            fi
        done
        if (( ${#conditions} )); then
            statements+="DELETE FROM $table_identifier WHERE ${(j: OR :)conditions};"
        fi
    done
    if (( ${tables[(I)threads]} )); then
        statements+="DELETE FROM \"threads\" WHERE \"id\" IN ($id_list);"
    fi
    statements+='COMMIT;'
    db_execute "$database" "$statements"
}

database_reference_count() {
    local database="$1"
    [[ ! -L "$database" ]] || { ERROR_DETAIL="Refusing symbolic-link database: $database"; return 1; }
    [[ -f "$database" ]] || { REPLY=0; return 0; }
    discover_thread_tables "$database" || return 1
    local -a tables=("${DISCOVERED_TABLES[@]}")
    selected_id_list_sql
    local id_list="$REPLY" total=0 table column table_identifier column_identifier
    local -a conditions=()
    for table in $tables; do
        conditions=()
        sql_identifier "$table"; table_identifier="$REPLY"
        if [[ "$table" == 'threads' ]]; then conditions+=("\"id\" IN ($id_list)"); fi
        for column in thread_id parent_thread_id child_thread_id; do
            if db_has_column "$database" "$table" "$column"; then
                sql_identifier "$column"; column_identifier="$REPLY"
                conditions+=("$column_identifier IN ($id_list)")
            fi
        done
        if (( ${#conditions} )); then
            db_query "$database" "SELECT COUNT(*) FROM $table_identifier WHERE ${(j: OR :)conditions};" || return 1
            [[ "$DB_RESULT" == <-> ]] || return 1
            (( total += DB_RESULT ))
        fi
    done
    REPLY="$total"
}

clean_session_index() {
    local file_path="$CODEX_HOME/session_index.jsonl"
    [[ ! -L "$file_path" ]] || return 1
    [[ -f "$file_path" ]] || return 0
    local temp="$TEMP_DIR/session-index.jsonl"
    : >| "$temp" || return 1
    local line id remove
    while IFS= read -r line || [[ -n "$line" ]]; do
        remove=0
        for id in $SELECTED_IDS; do
            if [[ "$line" == *"$id"* ]]; then remove=1; break; fi
        done
        (( remove )) || print -r -- "$line" >> "$temp" || return 1
    done < "$file_path"
    /bin/mv -f -- "$temp" "$file_path"
}

clean_global_state_files() {
    local -a files=(
        "$CODEX_HOME/.codex-global-state.json"(N)
        "$CODEX_HOME/.codex-global-state.json.bak"(N)
        "$CODEX_HOME"/..codex-global-state.json.tmp-*(N)
    )
    local file id hit temp mode
    for file in $files; do
        [[ -f "$file" && ! -L "$file" ]] || continue
        hit=0
        for id in $SELECTED_IDS; do
            if /usr/bin/grep -Fq -- "$id" "$file" 2>/dev/null; then hit=1; break; fi
        done
        (( hit )) || continue
        temp="$file.cleaner-tmp-$$-$RANDOM"
        [[ "$temp" == "$CODEX_HOME"/*cleaner-tmp-* ]] || return 1
        mode=$(/usr/bin/stat -f '%Lp' "$file") || return 1
        if ! "$OSASCRIPT" -l JavaScript "$JSON_HELPER" clean-json "$file" $SELECTED_IDS >| "$temp" 2>/dev/null; then
            /bin/rm -f -- "$temp"
            return 1
        fi
        /bin/chmod "$mode" "$temp" || { /bin/rm -f -- "$temp"; return 1; }
        /bin/mv -f -- "$temp" "$file" || { /bin/rm -f -- "$temp"; return 1; }
    done
    return 0
}

remove_target_items() {
    local -a sorted=("${(@On)TARGET_ITEMS}")
    local item
    for item in $sorted; do
        [[ -e "$item" || -L "$item" ]] || continue
        [[ -n "$item" && ! -L "$item" ]] || return 1
        is_within "$item" "$CODEX_HOME" || return 1
        [[ "${item:A}" != "$CODEX_HOME" ]] || return 1
        if [[ -d "$item" ]]; then
            /bin/rm -rf -- "$item" || return 1
        else
            /bin/rm -f -- "$item" || return 1
        fi
    done
}

assert_no_references() {
    local database count file id
    for database in $METADATA_DATABASE_NAMES; do
        database="$CODEX_HOME/$database"
        database_reference_count "$database" || return 1
        count="$REPLY"
        (( count == 0 )) || { ERROR_DETAIL="Database references remain in $database ($count row(s))."; return 1; }
    done

    local -a text_files=(
        "$CODEX_HOME/session_index.jsonl"(N)
        "$CODEX_HOME/.codex-global-state.json"(N)
        "$CODEX_HOME/.codex-global-state.json.bak"(N)
        "$CODEX_HOME"/..codex-global-state.json.tmp-*(N)
    )
    for file in $text_files; do
        [[ -f "$file" ]] || continue
        case "$file" in
            *.json|*.jsonl|*.bak|*tmp-*)
                for id in $SELECTED_IDS; do
                    if /usr/bin/grep -Fq -- "$id" "$file" 2>/dev/null; then
                        ERROR_DETAIL="Target reference remains in $file"
                        return 1
                    fi
                done
                ;;
        esac
    done

    for file in $TARGET_ITEMS; do
        if [[ -e "$file" || -L "$file" ]]; then
            ERROR_DETAIL="Target file or folder remains: $file"
            return 1
        fi
    done
    return 0
}

workspace_is_protected() {
    local workspace="$1"
    local -a protected=(
        / /System /Library /Applications /Users /Volumes /private /tmp
        "$HOME" "$HOME/Desktop" "$HOME/Documents" "$HOME/Downloads"
        "$CODEX_HOME" "$SCRIPT_DIR" "$BACKUP_PATH"
    )
    local protected_path protected_full
    for protected_path in $protected; do
        [[ -n "$protected_path" ]] || continue
        normalize_path "$protected_path" || continue
        protected_full="$REPLY"
        if [[ "$workspace" == "$protected_full" ]] || is_within "$protected_full" "$workspace"; then
            return 0
        fi
    done
    local -a system_trees=(/System /Library /Applications /usr /bin /sbin "$HOME/Library")
    for protected_path in $system_trees; do
        if is_within "$workspace" "$protected_path"; then return 0; fi
    done
    local -a components=("${(@s:/:)workspace}")
    (( ${#components} < 3 )) && return 0
    return 1
}

workspace_is_shared() {
    local workspace="$1"
    local index cwd
    for index in $REMAINING_INDICES; do
        cwd="${THREAD_CWDS[$index]}"
        [[ -n "$cwd" ]] || continue
        normalize_path "$cwd" || continue
        same_existing_path "$REPLY" "$workspace" && return 0
    done
    return 1
}

workspace_has_automation_reference() {
    local original="$1"
    local normalized="$2"
    local folder="$CODEX_HOME/automations"
    [[ -d "$folder" && ! -L "$folder" ]] || return 1
    local -a files=("$folder"/**/*(.N))
    local file result
    for file in $files; do
        result=$("$OSASCRIPT" -l JavaScript "$JSON_HELPER" contains-path "$file" "$original" "$normalized" 2>/dev/null) || {
            warn "Automation reference could not be inspected; workspace was kept: $file"
            return 0
        }
        result="${result//$'\r'/}"
        if [[ "$result" == 'true' ]]; then
            return 0
        fi
    done
    return 1
}

move_workspaces_to_trash() {
    typeset -A seen_workspaces
    local index original absolute normalized identity
    for index in $SELECTED_INDICES; do
        original="${THREAD_CWDS[$index]}"
        [[ -n "$original" ]] || continue
        absolute="${original:a}"
        [[ -e "$absolute" || -L "$absolute" ]] || continue
        if [[ -L "$absolute" ]]; then
            warn "Symbolic-link workspace was not removed: $original"
            continue
        fi
        normalize_path "$absolute" || { warn "Workspace path could not be normalized: $original"; (( MOVE_FAILURES++ )); continue; }
        normalized="$REPLY"
        path_identity "$normalized" || { warn "Workspace identity could not be verified: $original"; (( MOVE_FAILURES++ )); continue; }
        identity="$REPLY"
        [[ -z "${seen_workspaces[$identity]-}" ]] || continue
        seen_workspaces[$identity]=1

        if workspace_is_protected "$normalized"; then
            warn "Protected workspace was not removed: $normalized"
            continue
        fi
        if workspace_is_shared "$normalized"; then
            warn "Workspace is shared by another task and was not removed: $normalized"
            continue
        fi
        if workspace_has_automation_reference "$original" "$normalized"; then
            warn "Workspace is referenced by an automation and was not removed: $normalized"
            continue
        fi

        if ! "$OSASCRIPT" -l JavaScript "$JSON_HELPER" trash "$normalized" >/dev/null 2>&1; then
            warn "Could not move workspace to Trash: $normalized"
            (( MOVE_FAILURES++ ))
            continue
        fi
        if [[ -e "$normalized" || -L "$normalized" ]]; then
            warn "Trash operation returned without removing workspace: $normalized"
            (( MOVE_FAILURES++ ))
            continue
        fi
        print -P "%F{green}Moved workspace to Trash: $normalized%f"
    done
}

parse_arguments() {
    while (( $# )); do
        case "$1" in
            --id)
                (( $# >= 2 )) || die '--id requires a UUID.'
                REQUESTED_IDS+=("$2")
                shift 2
                ;;
            --list) LIST_ONLY=1; shift ;;
            --show-all) SHOW_ALL=1; shift ;;
            --execute) EXECUTE=1; shift ;;
            --yes) ASSUME_YES=1; shift ;;
            --remove-workspaces) REMOVE_WORKSPACES=1; shift ;;
            --codex-home)
                (( $# >= 2 )) || die '--codex-home requires a path.'
                CODEX_HOME="$2"
                shift 2
                ;;
            --backup-root)
                (( $# >= 2 )) || die '--backup-root requires a path.'
                BACKUP_ROOT="$2"
                shift 2
                ;;
            --skip-process-check) SKIP_PROCESS_CHECK=1; shift ;;
            --help|-h) usage; exit 0 ;;
            *) die "Unknown option: $1" ;;
        esac
    done
}

main() {
    parse_arguments "$@"
    print "Codex 로컬 작업 정리 도구 for macOS $VERSION"
    print '비공식 도구입니다. 복구 백업을 만든 뒤 로컬 Codex 메타데이터를 정리합니다.'

    require_command "$SQLITE3"
    require_command "$OSASCRIPT"
    require_command "$DITTO"
    (( SKIP_PROCESS_CHECK )) || require_command "$LSOF"
    [[ -f "$JSON_HELPER" ]] || die "Missing helper: $JSON_HELPER"

    TEMP_DIR=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/codex-task-cleaner.XXXXXX") || die 'Could not create a temporary directory.'
    CODEX_HOME="${CODEX_HOME:A}"
    BACKUP_ROOT="${BACKUP_ROOT:A}"
    [[ -d "$CODEX_HOME" && ! -L "$CODEX_HOME" ]] || die "Codex home was not found or is unsafe: $CODEX_HOME"
    assert_app_closed
    assert_supported_schema
    load_threads

    local -a user_indices=() all_indices=() candidates=()
    local i kind hidden_count
    for (( i=1; i<=${#THREAD_IDS}; i++ )); do
        all_indices+=("$i")
        thread_kind "$i"; kind="$REPLY"
        [[ "$kind" == '일반대화' ]] && user_indices+=("$i")
    done
    hidden_count=$(( ${#all_indices} - ${#user_indices} ))

    if (( LIST_ONLY )); then
        print_heading $([[ $SHOW_ALL == 1 ]] && print '전체 로컬 작업' || print '사용자 대화')
        if (( SHOW_ALL )); then show_threads $all_indices; else show_threads $user_indices; fi
        if (( ! SHOW_ALL && hidden_count > 0 )); then
            print "자동화·하위 작업 ${hidden_count}개는 숨겼습니다. 전체 목록은 --list --show-all로 확인할 수 있습니다."
        fi
        return 0
    fi

    local interactive=0 showing_all=0 selection workspace_choice confirmation
    if (( ${#REQUESTED_IDS} == 0 )); then interactive=1; fi
    if (( interactive )); then
        candidates=("${user_indices[@]}")
        while true; do
            if (( showing_all )); then print_heading '전체 로컬 작업'; else print_heading '사용자 대화'; fi
            show_threads $candidates
            print -P '%F{yellow}목록의 번호는 이번 실행에서만 사용하는 임시 번호입니다.%f'
            if (( ! showing_all && hidden_count > 0 )); then
                print "자동화·하위 작업 ${hidden_count}개는 안전을 위해 숨겼습니다."
                read -r "selection?삭제할 번호(여러 개는 1,2), 전체 보기 A, 취소 Return: "
            else
                read -r "selection?삭제할 번호(여러 개는 1,2), 취소 Return: "
            fi
            if [[ -z "$selection" ]]; then print -P '%F{green}취소했습니다. 아무것도 변경하지 않았습니다.%f'; return 0; fi
            if (( ! showing_all )) && [[ "${selection:u}" == 'A' ]]; then
                candidates=("${all_indices[@]}")
                showing_all=1
                continue
            fi
            break
        done
        local -a numbers=("${(@s:,:)selection}")
        local number
        for number in $numbers; do
            number="${number//[[:space:]]/}"
            [[ "$number" == <-> && number -ge 1 && number -le ${#candidates} ]] || die "잘못된 작업 번호입니다: $number"
            REQUESTED_IDS+=("${THREAD_IDS[${candidates[$number]}]}")
        done
    fi

    local id
    for id in $REQUESTED_IDS; do
        [[ "$id" =~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' ]] || die "Invalid task ID: $id"
        SELECTED_SET[$id]=1
    done
    collect_descendants

    SELECTED_IDS=("${(@k)SELECTED_SET}")
    SELECTED_INDICES=()
    REMAINING_INDICES=()
    typeset -A found_ids
    for (( i=1; i<=${#THREAD_IDS}; i++ )); do
        id="${THREAD_IDS[$i]}"
        if [[ -n "${SELECTED_SET[$id]-}" ]]; then
            SELECTED_INDICES+=("$i")
            found_ids[$id]=1
        else
            REMAINING_INDICES+=("$i")
        fi
    done
    for id in $SELECTED_IDS; do
        [[ -n "${found_ids[$id]-}" ]] || die "Task ID was not found: $id"
    done
    SELECTED_IDS=()
    for i in $SELECTED_INDICES; do SELECTED_IDS+=("${THREAD_IDS[$i]}"); done

    if find_automation_reference; then die "Selected task is referenced by an automation: $REPLY"; fi
    collect_target_items

    print_heading '최종 삭제 대상 확인'
    show_selected
    if (( ${#DESCENDANT_IDS} )); then warn "연결된 하위 작업도 함께 제거됩니다: ${(j:, :)DESCENDANT_IDS}"; fi
    print "제거할 메타데이터·세션 항목: ${#TARGET_ITEMS}"
    print '전체 복구 백업 위치:'
    print -P "%F{yellow}$BACKUP_ROOT%f"

    if (( interactive )); then
        read -r "workspace_choice?선택한 작업의 전용 폴더도 휴지통으로 보낼까요? [y/N]: "
        [[ "${workspace_choice:l}" == 'y' || "${workspace_choice:l}" == 'yes' ]] && REMOVE_WORKSPACES=1
        read -r "confirmation?실제 삭제하려면 DELETE를 정확히 입력하세요. 그 외 입력은 미리보기로 종료합니다: "
        [[ "$confirmation" == 'DELETE' ]] && EXECUTE=1
    fi
    if (( ! EXECUTE )); then print -P '%F{green}미리보기 완료. 아무것도 변경하지 않았습니다.%f'; return 0; fi
    if (( ! interactive && ! ASSUME_YES )); then
        read -r "confirmation?Type DELETE to permanently remove the selected local task metadata: "
        [[ "$confirmation" == 'DELETE' ]] || die 'Confirmation was not entered. Nothing was changed.'
    fi

    print_heading 'Backup'
    create_backup
    print -P "%F{green}Recovery backup created: $BACKUP_PATH%f"

    MUTATION_STARTED=1
    print_heading 'Metadata cleanup'
    local database
    for database in $METADATA_DATABASE_NAMES; do
        delete_database_rows "$CODEX_HOME/$database" || die "Database cleanup failed for $database: $ERROR_DETAIL"
    done
    clean_session_index || die 'Could not clean session_index.jsonl.'
    clean_global_state_files || die 'Could not safely clean a global state JSON file.'
    remove_target_items || die 'Refusing or unable to remove one of the selected session items.'
    assert_no_references || die "Verification failed. $ERROR_DETAIL"
    CLEANUP_VERIFIED=1

    print_heading 'Verified'
    print -P "%F{green}Deleted and verified ${#SELECTED_IDS} local task(s).%f"
    print -P "%F{yellow}Recovery backup kept at: $BACKUP_PATH%f"

    if (( REMOVE_WORKSPACES )); then
        print_heading 'Workspace cleanup'
        move_workspaces_to_trash
    fi
    if (( MOVE_FAILURES > 0 )); then
        warn "Task metadata deletion succeeded, but $MOVE_FAILURES workspace folder(s) could not be moved to Trash."
        return 2
    fi
    return 0
}

main "$@"
