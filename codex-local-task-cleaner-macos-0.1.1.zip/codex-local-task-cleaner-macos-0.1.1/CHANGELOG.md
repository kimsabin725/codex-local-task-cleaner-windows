# Changelog

## 0.1.1 - 2026-08-18

- Added cleanup and verification for `queue_1.sqlite` task references.
- Refused symbolic links across every core metadata file before backup or mutation.
- Refused unknown SQLite files and migrations newer than the supported schema.
- Replaced raw database copies with consistent SQLite snapshots and integrity checks.
- Added file-handle checks so helper/background processes cannot write during cleanup.
- Verified database integrity and selected-task recovery after automatic restore.
- Compared existing workspaces by filesystem identity and normalized automation paths for case and Unicode differences.
- Added regression tests for the new fail-closed safeguards.

## 0.1.0 - 2026-08-18

- Initial macOS test release.
- Added interactive and command-line task selection.
- Added descendant-task discovery and automation-reference protection.
- Added full recovery backup before metadata changes.
- Added automatic restore when cleanup or verification fails.
- Added Finder Trash-compatible workspace cleanup through macOS Foundation.
- Added shared, protected and symbolic-link workspace safeguards.
- Added isolated macOS regression tests and GitHub Actions workflow.
