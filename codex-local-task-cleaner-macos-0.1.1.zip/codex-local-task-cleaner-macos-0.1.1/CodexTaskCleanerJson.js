ObjC.import('Foundation');

function containsAnyId(text, ids) {
    if (typeof text !== 'string') return false;
    for (var i = 0; i < ids.length; i += 1) {
        if (text.indexOf(ids[i]) !== -1) return true;
    }
    return false;
}

function cleanJsonValue(value, ids, removeMarker) {
    if (value === null || typeof value === 'number' || typeof value === 'boolean') {
        return value;
    }
    if (typeof value === 'string') {
        return containsAnyId(value, ids) ? removeMarker : value;
    }
    if (Array.isArray(value)) {
        var cleanedArray = [];
        for (var i = 0; i < value.length; i += 1) {
            var cleanedItem = cleanJsonValue(value[i], ids, removeMarker);
            if (cleanedItem !== removeMarker) cleanedArray.push(cleanedItem);
        }
        return cleanedArray;
    }
    if (typeof value === 'object') {
        var cleanedObject = {};
        Object.keys(value).forEach(function (key) {
            if (containsAnyId(key, ids)) return;
            var cleanedValue = cleanJsonValue(value[key], ids, removeMarker);
            if (cleanedValue !== removeMarker) cleanedObject[key] = cleanedValue;
        });
        return cleanedObject;
    }
    return value;
}

function cleanJson(path, ids) {
    var app = Application.currentApplication();
    app.includeStandardAdditions = true;
    var raw = app.read(Path(path), { using: 'utf8' });
    var parsed = JSON.parse(raw);
    var removeMarker = {};
    var cleaned = cleanJsonValue(parsed, ids, removeMarker);
    if (cleaned === removeMarker) cleaned = {};
    return JSON.stringify(cleaned);
}

function comparableText(value) {
    return String(value).normalize('NFC').toLowerCase();
}

function fileContainsPath(path, candidates) {
    var app = Application.currentApplication();
    app.includeStandardAdditions = true;
    var raw = comparableText(app.read(Path(path), { using: 'utf8' }));
    for (var i = 0; i < candidates.length; i += 1) {
        if (raw.indexOf(comparableText(candidates[i])) !== -1) return 'true';
    }
    return 'false';
}

function errorDescription(errorRef) {
    try {
        var error = errorRef[0];
        if (error) return ObjC.unwrap(error.localizedDescription);
    } catch (_) {}
    return 'unknown macOS file error';
}

function moveToTrash(path) {
    var manager = $.NSFileManager.defaultManager;
    var url = $.NSURL.fileURLWithPath($(path));
    var resultingUrl = Ref();
    var error = Ref();
    var ok = manager.trashItemAtURLResultingItemURLError(url, resultingUrl, error);
    if (!ok) throw new Error(errorDescription(error));
    try {
        return ObjC.unwrap(resultingUrl[0].path);
    } catch (_) {
        return '';
    }
}

function run(argv) {
    if (argv.length < 1) throw new Error('Missing helper command.');
    var command = argv[0];
    if (command === 'clean-json') {
        if (argv.length < 3) throw new Error('clean-json requires a path and at least one task ID.');
        return cleanJson(argv[1], argv.slice(2));
    }
    if (command === 'trash') {
        if (argv.length !== 2) throw new Error('trash requires exactly one path.');
        return moveToTrash(argv[1]);
    }
    if (command === 'contains-path') {
        if (argv.length < 3) throw new Error('contains-path requires a file and at least one path.');
        return fileContainsPath(argv[1], argv.slice(2));
    }
    throw new Error('Unknown helper command: ' + command);
}
