#!/bin/zsh

emulate -LR zsh
setopt ERR_EXIT NO_UNSET PIPE_FAIL NO_NOMATCH
umask 077

readonly PACKAGE_ROOT="${0:A:h:h}"
readonly CLEANER="$PACKAGE_ROOT/CodexTaskCleaner.sh"
readonly SQLITE3='/usr/bin/sqlite3'

/bin/zsh -n "$CLEANER"
/bin/zsh -n "$PACKAGE_ROOT/CodexTaskCleaner.command"
[[ -x "$SQLITE3" ]] || { print -u2 'sqlite3 is unavailable'; exit 1; }

TEST_ROOT=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/codex-cleaner-tests.XXXXXX")
cleanup() {
    if [[ "${CODEX_CLEANER_KEEP_TEST_ROOT:-0}" == '1' ]]; then
        print -u2 "Test root kept at: $TEST_ROOT"
        return
    fi
    local root_abs="${TEST_ROOT:A}"
    local temp_abs="${TMPDIR:-/tmp}"
    temp_abs="${temp_abs:A}"
    if [[ -n "$root_abs" && "$root_abs" == "$temp_abs"/codex-cleaner-tests.* && -d "$root_abs" ]]; then
        /bin/rm -rf -- "$root_abs"
    fi
}
trap cleanup EXIT

readonly ROOT_ID='11111111-1111-4111-8111-111111111111'
readonly CHILD_ID='22222222-2222-4222-8222-222222222222'
readonly REMAINING_ID='33333333-3333-4333-8333-333333333333'

fail() {
    print -u2 "TEST FAILED: $*"
    exit 1
}

assert_file() {
    [[ -f "$1" ]] || fail "expected file: $1"
}

assert_dir() {
    [[ -d "$1" ]] || fail "expected directory: $1"
}

assert_missing() {
    [[ ! -e "$1" && ! -L "$1" ]] || fail "expected missing path: $1"
}

assert_sql_count() {
    local database="$1" sql="$2" expected="$3"
    local actual
    actual=$("$SQLITE3" "$database" "$sql")
    [[ "$actual" == "$expected" ]] || fail "SQL count was $actual, expected $expected: $sql"
}

make_fixture() {
    local fixture="$1"
    local invalid_json="$2"
    local codex="$fixture/.codex"
    local shared="$fixture/shared-workspace"
    local child_workspace="$fixture/child-workspace"
    local root_rollout="$codex/sessions/2026/08/18/rollout-$ROOT_ID.jsonl"
    local child_rollout="$codex/sessions/2026/08/18/rollout-$CHILD_ID.jsonl"
    local remaining_rollout="$codex/sessions/2026/08/18/rollout-$REMAINING_ID.jsonl"

    /bin/mkdir -p "$codex/sessions/2026/08/18" "$codex/thread-writer-locks" \
        "$codex/visualizations/2026/08/18/$ROOT_ID" "$codex/visualizations/2026/08/18/$CHILD_ID" \
        "$codex/automations" "$shared" "$child_workspace"

    "$SQLITE3" "$codex/state_5.sqlite" <<SQL
CREATE TABLE _sqlx_migrations (version INTEGER, description TEXT, success INTEGER);
INSERT INTO _sqlx_migrations VALUES (48, 'supported state schema', 1);
CREATE TABLE threads (
  id TEXT PRIMARY KEY,
  rollout_path TEXT NOT NULL,
  cwd TEXT NOT NULL,
  title TEXT,
  source TEXT,
  thread_source TEXT,
  updated_at_ms INTEGER
);
CREATE TABLE thread_spawn_edges (parent_thread_id TEXT, child_thread_id TEXT);
INSERT INTO threads VALUES ('$ROOT_ID', '$root_rollout', '$shared', CAST(X'526F6F7420ED858CEC8AA4ED8AB820EC9E91EC9785' AS TEXT), '', '', 1800000000000);
INSERT INTO threads VALUES ('$CHILD_ID', '$child_rollout', '$child_workspace', 'Child test task', 'subagent', 'subagent', 1799999999000);
INSERT INTO threads VALUES ('$REMAINING_ID', '$remaining_rollout', '$shared', 'Remaining task', '', '', 1799999998000);
INSERT INTO thread_spawn_edges VALUES ('$ROOT_ID', '$CHILD_ID');
SQL

    local database table
    for database in logs_2.sqlite goals_1.sqlite memories_1.sqlite; do
        table="${database%%_*}_entries"
        local migration=1
        [[ "$database" == 'logs_2.sqlite' || "$database" == 'goals_1.sqlite' ]] && migration=2
        "$SQLITE3" "$codex/$database" <<SQL
CREATE TABLE _sqlx_migrations (version INTEGER, description TEXT, success INTEGER);
INSERT INTO _sqlx_migrations VALUES ($migration, 'supported auxiliary schema', 1);
CREATE TABLE $table (thread_id TEXT, value TEXT);
INSERT INTO $table VALUES ('$ROOT_ID', 'root');
INSERT INTO $table VALUES ('$CHILD_ID', 'child');
INSERT INTO $table VALUES ('$REMAINING_ID', 'remaining');
SQL
    done

    "$SQLITE3" "$codex/queue_1.sqlite" <<SQL
CREATE TABLE _sqlx_migrations (version INTEGER, description TEXT, success INTEGER);
INSERT INTO _sqlx_migrations VALUES (1, 'supported queue schema', 1);
CREATE TABLE queued_items (id TEXT, thread_id TEXT, payload_json TEXT);
INSERT INTO queued_items VALUES ('queue-root', '$ROOT_ID', '{}');
INSERT INTO queued_items VALUES ('queue-child', '$CHILD_ID', '{}');
INSERT INTO queued_items VALUES ('queue-remaining', '$REMAINING_ID', '{}');
SQL

    print '{"id":"'$ROOT_ID'"}' > "$root_rollout"
    print '{"id":"'$CHILD_ID'"}' > "$child_rollout"
    print '{"id":"'$REMAINING_ID'"}' > "$remaining_rollout"
    print 'lock' > "$codex/thread-writer-locks/$ROOT_ID.lock"
    print 'lock' > "$codex/thread-writer-locks/$CHILD_ID.lock"
    print 'root visualization' > "$codex/visualizations/2026/08/18/$ROOT_ID/item.txt"
    print 'child visualization' > "$codex/visualizations/2026/08/18/$CHILD_ID/item.txt"
    print '{"id":"'$ROOT_ID'"}' > "$codex/session_index.jsonl"
    print '{"id":"'$CHILD_ID'"}' >> "$codex/session_index.jsonl"
    print '{"id":"'$REMAINING_ID'"}' >> "$codex/session_index.jsonl"
    print '{"version":"test"}' > "$codex/version.json"

    if [[ "$invalid_json" == 'yes' ]]; then
        print '{invalid-json "'$ROOT_ID'"' > "$codex/.codex-global-state.json"
    else
        print '{"selected":"'$ROOT_ID'","items":["'$CHILD_ID'","'$REMAINING_ID'"],"keep":"ok"}' > "$codex/.codex-global-state.json"
    fi
}

print 'Test 1: successful cleanup, descendant deletion, shared-folder protection, and Trash move'
SUCCESS_FIXTURE="$TEST_ROOT/success"
make_fixture "$SUCCESS_FIXTURE" no
SUCCESS_CODEX="$SUCCESS_FIXTURE/.codex"
SUCCESS_BACKUPS="$SUCCESS_FIXTURE/backups"

list_output=$(/bin/zsh "$CLEANER" --list --codex-home "$SUCCESS_CODEX" --backup-root "$SUCCESS_BACKUPS" --skip-process-check)
[[ "$list_output" == *'Root 테스트 작업'* && "$list_output" == *'Remaining task'* ]] || fail 'list output is incomplete'
[[ "$list_output" != *'Child test task'* ]] || fail 'subagent should be hidden in default list'

/bin/zsh "$CLEANER" --id "$ROOT_ID" --execute --yes --remove-workspaces \
    --codex-home "$SUCCESS_CODEX" --backup-root "$SUCCESS_BACKUPS" --skip-process-check

assert_sql_count "$SUCCESS_CODEX/state_5.sqlite" "SELECT COUNT(*) FROM threads WHERE id IN ('$ROOT_ID','$CHILD_ID');" 0
assert_sql_count "$SUCCESS_CODEX/state_5.sqlite" "SELECT COUNT(*) FROM threads WHERE id='$REMAINING_ID';" 1
assert_sql_count "$SUCCESS_CODEX/logs_2.sqlite" "SELECT COUNT(*) FROM logs_entries WHERE thread_id IN ('$ROOT_ID','$CHILD_ID');" 0
assert_sql_count "$SUCCESS_CODEX/queue_1.sqlite" "SELECT COUNT(*) FROM queued_items WHERE thread_id IN ('$ROOT_ID','$CHILD_ID');" 0
assert_missing "$SUCCESS_CODEX/sessions/2026/08/18/rollout-$ROOT_ID.jsonl"
assert_missing "$SUCCESS_CODEX/sessions/2026/08/18/rollout-$CHILD_ID.jsonl"
assert_file "$SUCCESS_CODEX/sessions/2026/08/18/rollout-$REMAINING_ID.jsonl"
assert_missing "$SUCCESS_CODEX/thread-writer-locks/$ROOT_ID.lock"
assert_missing "$SUCCESS_CODEX/visualizations/2026/08/18/$ROOT_ID"
assert_dir "$SUCCESS_FIXTURE/shared-workspace"
assert_missing "$SUCCESS_FIXTURE/child-workspace"
/usr/bin/grep -Fq "$REMAINING_ID" "$SUCCESS_CODEX/.codex-global-state.json" || fail 'remaining JSON reference was removed'
if /usr/bin/grep -Fq "$ROOT_ID" "$SUCCESS_CODEX/.codex-global-state.json" || /usr/bin/grep -Fq "$CHILD_ID" "$SUCCESS_CODEX/.codex-global-state.json"; then
    fail 'deleted JSON reference remains'
fi
manifest=("$SUCCESS_BACKUPS"/backup-*/manifest.json(N[1]))
(( ${#manifest} == 1 )) || fail 'backup manifest was not created'
backup_state="${manifest[1]:h}/core/state_5.sqlite"
assert_sql_count "$backup_state" 'PRAGMA integrity_check;' ok

print 'Test 2: invalid global JSON triggers automatic restore'
RESTORE_FIXTURE="$TEST_ROOT/restore"
make_fixture "$RESTORE_FIXTURE" yes
RESTORE_CODEX="$RESTORE_FIXTURE/.codex"
RESTORE_BACKUPS="$RESTORE_FIXTURE/backups"

if /bin/zsh "$CLEANER" --id "$ROOT_ID" --execute --yes \
    --codex-home "$RESTORE_CODEX" --backup-root "$RESTORE_BACKUPS" --skip-process-check; then
    fail 'cleanup unexpectedly succeeded with invalid global JSON'
fi

assert_sql_count "$RESTORE_CODEX/state_5.sqlite" "SELECT COUNT(*) FROM threads WHERE id IN ('$ROOT_ID','$CHILD_ID');" 2
assert_sql_count "$RESTORE_CODEX/logs_2.sqlite" "SELECT COUNT(*) FROM logs_entries WHERE thread_id IN ('$ROOT_ID','$CHILD_ID');" 2
assert_sql_count "$RESTORE_CODEX/queue_1.sqlite" "SELECT COUNT(*) FROM queued_items WHERE thread_id IN ('$ROOT_ID','$CHILD_ID');" 2
assert_file "$RESTORE_CODEX/sessions/2026/08/18/rollout-$ROOT_ID.jsonl"
assert_file "$RESTORE_CODEX/sessions/2026/08/18/rollout-$CHILD_ID.jsonl"
/usr/bin/grep -Fq "$ROOT_ID" "$RESTORE_CODEX/.codex-global-state.json" || fail 'global state was not restored'

print 'Test 3: symbolic-link metadata is rejected before backup or mutation'
if [[ "$(/usr/bin/uname -s)" == 'Darwin' ]]; then
    SYMLINK_FIXTURE="$TEST_ROOT/symlink"
    make_fixture "$SYMLINK_FIXTURE" no
    SYMLINK_CODEX="$SYMLINK_FIXTURE/.codex"
    SYMLINK_BACKUPS="$SYMLINK_FIXTURE/backups"
    EXTERNAL_INDEX="$SYMLINK_FIXTURE/external-session-index.jsonl"
    /bin/cp "$SYMLINK_CODEX/session_index.jsonl" "$EXTERNAL_INDEX"
    /bin/rm "$SYMLINK_CODEX/session_index.jsonl"
    /bin/ln -s "$EXTERNAL_INDEX" "$SYMLINK_CODEX/session_index.jsonl"

    if /bin/zsh "$CLEANER" --id "$ROOT_ID" --execute --yes \
        --codex-home "$SYMLINK_CODEX" --backup-root "$SYMLINK_BACKUPS" --skip-process-check; then
        fail 'cleanup unexpectedly accepted a symbolic-link metadata file'
    fi
    assert_sql_count "$SYMLINK_CODEX/state_5.sqlite" "SELECT COUNT(*) FROM threads WHERE id IN ('$ROOT_ID','$CHILD_ID');" 2
    /usr/bin/grep -Fq "$ROOT_ID" "$EXTERNAL_INDEX" || fail 'symbolic-link target was modified'
    symlink_backups=("$SYMLINK_BACKUPS"/backup-*(N))
    (( ${#symlink_backups} == 0 )) || fail 'backup should not start after unsafe metadata is detected'
else
    print '  skipped: symbolic-link safety test runs on macOS CI'
fi

print 'Test 4: newer and unknown storage files fail closed'
FUTURE_FIXTURE="$TEST_ROOT/future"
make_fixture "$FUTURE_FIXTURE" no
FUTURE_CODEX="$FUTURE_FIXTURE/.codex"
FUTURE_BACKUPS="$FUTURE_FIXTURE/backups"
"$SQLITE3" "$FUTURE_CODEX/state_5.sqlite" "INSERT INTO _sqlx_migrations VALUES (49, 'future schema', 1);"
if /bin/zsh "$CLEANER" --list --codex-home "$FUTURE_CODEX" --backup-root "$FUTURE_BACKUPS" --skip-process-check; then
    fail 'cleaner unexpectedly accepted a newer migration'
fi
"$SQLITE3" "$FUTURE_CODEX/state_5.sqlite" "DELETE FROM _sqlx_migrations WHERE version=49;"
"$SQLITE3" "$FUTURE_CODEX/future_1.sqlite" 'CREATE TABLE future_data (value TEXT);'
if /bin/zsh "$CLEANER" --list --codex-home "$FUTURE_CODEX" --backup-root "$FUTURE_BACKUPS" --skip-process-check; then
    fail 'cleaner unexpectedly accepted an unknown SQLite file'
fi

print 'Test 5: case-insensitive automation path references are protected'
AUTOMATION_FIXTURE="$TEST_ROOT/automation"
make_fixture "$AUTOMATION_FIXTURE" no
AUTOMATION_CODEX="$AUTOMATION_FIXTURE/.codex"
AUTOMATION_BACKUPS="$AUTOMATION_FIXTURE/backups"
AUTOMATION_WORKSPACE="$AUTOMATION_FIXTURE/AutomationWorkspace"
/bin/mkdir -p "$AUTOMATION_WORKSPACE"
"$SQLITE3" "$AUTOMATION_CODEX/state_5.sqlite" "UPDATE threads SET cwd='${AUTOMATION_WORKSPACE//\'/\'\'}' WHERE id='$ROOT_ID';"
print -r -- "workspace = ${AUTOMATION_WORKSPACE:l}" > "$AUTOMATION_CODEX/automations/path-reference.txt"
/bin/zsh "$CLEANER" --id "$ROOT_ID" --execute --yes --remove-workspaces \
    --codex-home "$AUTOMATION_CODEX" --backup-root "$AUTOMATION_BACKUPS" --skip-process-check
assert_sql_count "$AUTOMATION_CODEX/state_5.sqlite" "SELECT COUNT(*) FROM threads WHERE id='$ROOT_ID';" 0
assert_dir "$AUTOMATION_WORKSPACE"

print 'Test 6: case aliases of the same workspace are treated as shared when supported'
CASE_FIXTURE="$TEST_ROOT/case-identity"
make_fixture "$CASE_FIXTURE" no
CASE_CODEX="$CASE_FIXTURE/.codex"
CASE_BACKUPS="$CASE_FIXTURE/backups"
CASE_WORKSPACE="$CASE_FIXTURE/CaseWorkspace"
CASE_ALIAS="$CASE_FIXTURE/caseworkspace"
/bin/mkdir -p "$CASE_WORKSPACE"
if [[ -d "$CASE_ALIAS" ]]; then
    "$SQLITE3" "$CASE_CODEX/state_5.sqlite" "UPDATE threads SET cwd='$CASE_WORKSPACE' WHERE id='$ROOT_ID'; UPDATE threads SET cwd='$CASE_ALIAS' WHERE id='$REMAINING_ID';"
    /bin/zsh "$CLEANER" --id "$ROOT_ID" --execute --yes --remove-workspaces \
        --codex-home "$CASE_CODEX" --backup-root "$CASE_BACKUPS" --skip-process-check
    assert_dir "$CASE_WORKSPACE"
else
    print '  skipped: filesystem is case-sensitive'
fi

if [[ "$(/usr/bin/uname -s)" == 'Darwin' && -x /usr/sbin/lsof ]]; then
    print 'Test 7: an open database handle is detected on macOS'
    OPEN_FIXTURE="$TEST_ROOT/open-handle"
    make_fixture "$OPEN_FIXTURE" no
    OPEN_CODEX="$OPEN_FIXTURE/.codex"
    OPEN_BACKUPS="$OPEN_FIXTURE/backups"
    /usr/bin/tail -f "$OPEN_CODEX/state_5.sqlite" >/dev/null 2>&1 &
    holder_pid=$!
    /bin/sleep 1
    if /bin/zsh "$CLEANER" --list --codex-home "$OPEN_CODEX" --backup-root "$OPEN_BACKUPS"; then
        /bin/kill "$holder_pid" 2>/dev/null || true
        wait "$holder_pid" 2>/dev/null || true
        fail 'cleaner unexpectedly accepted an open database handle'
    fi
    /bin/kill "$holder_pid" 2>/dev/null || true
    wait "$holder_pid" 2>/dev/null || true
fi

print 'All macOS cleaner tests passed.'
