#!/bin/zsh

emulate -LR zsh
readonly SCRIPT_DIR="${0:A:h}"

/bin/zsh "$SCRIPT_DIR/CodexTaskCleaner.sh" "$@"
exit_code=$?

print
if (( exit_code == 2 )); then
    print 'Task deletion completed, but one or more optional workspace folders remain.'
elif (( exit_code != 0 )); then
    print "Cleaner stopped with exit code $exit_code."
fi
read -r "reply?Press Return to close..."
exit $exit_code
